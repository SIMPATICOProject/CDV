var app_parameters={
		host_param: 'localhost',
		port_param: '8082',
		findById_apipath: 'service-manager/api/v1/services/',
		update_apipath: 'service-manager/api/v1/services/',
		create_apipath: 'service-manager/api/v1/services/',
		getServices_apipath: 'service-manager/api/v1/services/',
		getPDataCategoryTree_apipath: 'service-manager/api/v1/pdatafields/category/tree',
		getServiceReportbyType_apipath: 'service-manager/api/v1/service_report/type',
		getServiceReportbySector_apipath: 'service-manager/api/v1/service_report/sector',
		getServByUrl_apipath: 'service-manager/api/v1/services/searchByUrl?url='
};
